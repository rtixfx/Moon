export default {
    public: [],
    dashboard: []
}